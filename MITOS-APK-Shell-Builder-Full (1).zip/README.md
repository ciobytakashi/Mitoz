# MITOS APK Shell Builder — Full package

Supports both Android source-code ZIPs and website/HTML ZIPs.

## Install
Copy the contents of this package into the root of your MITOS GitHub repository, preserving folders:
- `.github/workflows/apk-shell-builder.yml`
- `scripts/build_apk.py`
- `builder.json`
- `input/.gitkeep`

Commit the files. Put one source ZIP in `input/` and commit it. Open **Actions → MITOS APK Shell Builder → Run workflow**. Download the `MITOS-apk` artifact from the completed run.

## Android source ZIP
Must contain `settings.gradle` or `settings.gradle.kts` and an `app` module with its Gradle build file. The workflow uses JDK 17 and Gradle 8.9, retaining the supplied project's own Android/Gradle configuration.

## Website ZIP
Must contain `index.html` (or `index.htm`) and its local assets. The workflow creates an Android WebView app with default application ID `com.mitos.app`, Android Gradle Plugin 8.7.3, compile SDK 35 and min SDK 23.

## Settings
Edit `builder.json` for app name, package ID, version, entry HTML file, and JavaScript/file access. Manual workflow runs also expose app name and package ID inputs.

## Important limitations
- This first release outputs a debug APK, not a signed Play Store release.
- Website ZIPs must contain browser-ready static files. React/Vue/Vite source usually needs its built output (often `dist/`) included with `index.html` at the website root.
- Server-side backends (PHP, Python, Node), remote databases and native device features are not automatically packaged.
- Android source ZIPs are built as supplied; the builder does not automatically fix project-specific compile errors.
- Review ZIP contents before building. The workflow extracts untrusted input in an isolated GitHub Actions runner.
