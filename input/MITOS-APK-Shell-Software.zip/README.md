# MITOS APK Shell

A mobile-first website application designed to be packaged by the existing MITOS `build_apk.py` website-to-WebView path.

## Project layout

- `index.html` — complete MITOS APK Shell interface (the builder's required website entry point)
- `README.md` — this file

## Supported input project formats

The interface validates ZIP central-directory entries and accepts:
- Website / HTML projects containing root-level `index.html` or `index.htm`
- Android Gradle projects containing root-level `settings.gradle` or `settings.gradle.kts` and `app/build.gradle` or `app/build.gradle.kts`

These are the formats described by the existing builder. Other formats are not claimed as supported.

## GitHub integration

The interface calls the GitHub REST API directly from the WebView:
- Repository metadata and default branch
- Contents API to upload the selected ZIP into `input/`
- Actions workflow dispatch for `.github/workflows/apk-shell-builder.yml`
- Workflow run history and run artifacts
- Authenticated artifact archive download

The existing workflow must allow `workflow_dispatch`. The token is held in JavaScript memory only and is not persisted in local storage or cookies. For a private repository, use a fine-grained token restricted to the one repository with Contents read/write, Actions read/write, and Metadata read permissions. Organization policies may impose additional requirements.

## Important configuration limitation

The application-name and package-ID fields are informational only. The interface does not send unverified workflow inputs. The APK builder will use its own defaults (`MITOS` and `com.mitos.app`) unless the existing workflow explicitly passes `APP_NAME` and `PACKAGE_ID` to `build_apk.py`.

## Upload instructions

Upload `MITOS-APK-Shell-Software.zip` directly into the existing repository's `input/` directory. The ZIP root must contain `index.html`; do not put the files inside an additional enclosing folder.

## Limitations

- GitHub API access requires an internet connection and a valid token.
- GitHub API limits and repository policy apply.
- The artifact download is the GitHub Actions artifact ZIP archive. The APK file is inside that downloaded archive.
- ZIP64 archives are not accepted by the client-side validator.
- A 90 MB client-side ZIP limit is applied to keep the mobile upload request manageable.
- The UI reports workflow states from GitHub; it never declares a build successful before GitHub reports success.
